<?php

include("include/header.php");


include("include/navbar.php");


?>




  <section>
  <div class="display-4 my-2"><a href="index.php">DASHBOARD</a></div>

      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1 class="m-0">Dashboard</h1>
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Dashboard v1</li>
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>

    <section class="content">
      <div class="container-fluid">
           <div class="container">
           <h4 class="text-center"><strong>PATIENTS'S REPORT</strong></h4>
           <div class="row d-flex justify-content-center">
           <div class="col-md-8">
           <div class="card shadow min-vh-50"> 
           <div class="card-body"> 
           <div class="result">        
   

      </div>
      </div>
    </div>
  </div>
</div>
      </div>
  </section>

<?php include("footer.php"); ?>






<script type="text/javascript">
  
 $(document).ready(function(){
   
   show();
   function show(){

    $.ajax({
     url:"ajax/report.php",
     method:"POST",
     success:function(data){
      $(".result").html(data);
     }


    });


   }




 });








</script>






</body>
</html>