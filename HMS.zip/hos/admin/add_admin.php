<?php

include("include/header.php");


include("include/navbar.php");


?>




     <section>
      <div class="display-4 my-2"><a href="index.php">DASHBOARD</a></div>
             <div class="container">
             <div class="row d-flex justify-content-center">
             <div class="col-md-6">
              <div class="card shadow min-vh-50">
              <div class="card-body">
                <h3 class="text-center my-3 text-success">Add New Admin</h3>
                <div class="result"></div>
                <form method="POST" id="add_admin">
                <label class="pt-2">Username</label>
                <input type="text" name="username" id="username" class="form-control" placeholder="Enter Username">
                <label class="pt-3">Password</label>
                <input type="password" name="password" id="password" class="form-control" placeholder="Enter Password">
                <label class="pt-3">Confirm Password</label>
                <input type="password" name="cpass" id="cpass" class="form-control" placeholder="Enter Confirm Password">
                <input type="submit" name="add" id="add" value="Add New Admin" class="form-control btn btn-success my-3">
              </form>
              </div>
             </div>
           </div>


              <div class="col-md-10">
              <div class="card shadow min-vh-50">
               <div class="card-body">
                <div class="show">

               </div>
              </div>
              </div>
            </div>
          </div>
      </div>
  </section>




<script type="text/javascript">
  
 $(document).ready(function(){

    $("#add").click(function(e){
      e.preventDefault();

      $.ajax({
        url:"ajax/add_admin.php",
        method:"POST",
        data:$("#add_admin").serialize(),
        success:function(data){
          $(".result").html(data);
        }
      });      
    });

   show();
   function show(){

    $.ajax({
    url:"ajax/show_admin.php",
    method:"POST",
    success:function(data){
      $(".show").html(data);
    }
    });
 
   $(document).on("click",".remove",function(){
     var id = $(this).attr('id');
     var action = "remove";


       $.ajax({
         url:"ajax/delete_admin.php",
         method:"POST",
         data:{id:id,action,action},
         success:function(data){
          show();
         }


       });

   });



   }

   

 });








</script>





<?php include("include/footer.php"); ?>