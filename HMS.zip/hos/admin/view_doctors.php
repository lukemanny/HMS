<?php

include("include/header.php");
include("include/navbar.php");


?>


  <section>
  <div class="display-4 my-2"><a href="index.php">DASHBOARD</a></div>
        <div class="container">
          <div class="row">
            <div class="col-md-6">
              <?php
         

           include("../include/db.php");

           $id = $_GET['id'];


           $query = "SELECT * FROM doctor WHERE id='$id' ";
           $res = mysqli_query($connect,$query);

           $row = mysqli_fetch_array($res);


          ?>
         <h3 class="text-center text-success"><strong><?php echo $row['firstname'] ." ". $row['surname']."'s Details ";  ?></strong></h3>
         <div class="card shadow min-vh-50">
         <div class="card-body">
          <center>
           <img src="../doctor/img/<?php echo $row['profile']; ?>" class='rounded-circle' style='height: 150px; width: 150px;'>
          </center>
            <h5 class="pt-4">Email Address:: <?php echo $row['email']; ?></h5>
            <h5 class="pt-2">PHONE NO::  <?php echo $row['phone']; ?></h5>
            <h5 class="pt-2">GENDER::  <?php echo $row['gender']; ?></h5>
            <h5 class="pt-2">State::  <?php echo $row['state']; ?></h5>
            <h5 class="pt-2">SALARY::  #<?php echo number_format($row['salary'],2); ?></h5>
            <h5 class="pt-2">DATE APPLIED::  <?php echo $row['data_reg']; ?></h5>

           </div>
           </div>
           </div>
          
             <div class="col-md-6 my-3">
              <div class="card shadow min-vh-50 my-4">
                <div class="card-body">
                  <h5 class="text-center">UPDATE SALARY</h5>

       <?php

if(isset($_POST['update'])){

$salary = $_POST['salary'];

$error = array();

if(empty($salary)){
  $error['e'] = "ENTER SALARY";
}


$output ="";


if(isset($error['e'])){
   
 $output .="<h5 class='alert alert-danger text-center'>".$error['e']."</h5>";
}else{

}

if(count($error) < 1){
    
    $query = "UPDATE doctor SET salary='$salary' WHERE id='$id' ";
    $res = mysqli_query($connect,$query);

    if($res){
      $output .="<p class='alert alert-success'>Salary Updated Successful</p>";
    }else{
      $output .="<p class='alert alert-danger'>Oops failed!</p>";
    }
}




echo $output;
}

?>           <div class="result"></div>
                  <form method="POST">
                    <label class="pt-3">SALARY</label>
                    <input type="text" name="salary" id="salary" class="form-control" placeholder="Enter Salary">
                    <input type="submit" name="update" id="change" value="UPDATE" class="form-control btn btn-success btn-lg my-3">


                  </form>
            
             </div>
           </div>
            </div>

    </div>
  </div>
</div>
  </section>

<?php include("footer.php"); ?>









</body>
</html>