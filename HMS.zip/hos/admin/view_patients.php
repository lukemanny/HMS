<?php

include("include/header.php");
include("include/navbar.php");

?>


  <section>
  <div class="display-4 my-2"><a href="index.php">DASHBOARD</a></div>
        <div class="container">
          <div class="row d-flex justify-content-center">
            <div class="col-md-8">
              <?php
         

           include("../include/db.php");

           $id = $_GET['id'];


           $query = "SELECT * FROM patient WHERE id='$id' ";
           $res = mysqli_query($connect,$query);

           $row = mysqli_fetch_array($res);


          ?>
         <h3 class="text-center text-success"><strong><?php echo $row['firstname'] ." ". $row['surname']."'s Details ";  ?></strong></h3>
         <div class="card shadow min-vh-50">
         <div class="card-body">
          <center>
           <img src="../patient/img/<?php echo $row['profile']; ?>" class='rounded-circle' style='height: 150px; width: 150px;'>
          </center>
           <table class="table table-striped table-bordered">
            <tr>
            <td class="text-center">Email Address</td><td><?php echo $row['email']; ?></td>
            </tr>
            <tr>
            <td class="text-center">Email Address</td><td><?php echo $row['phone']; ?></td>
            </tr>
            <tr>
            <td class="text-center">Email Address</td><td><?php echo $row['gender']; ?></td>
            </tr>
            <tr>
            <td class="text-center">Email Address</td><td><?php echo $row['state']; ?></td>
            </tr>
            <td class="text-center">Email Address</td><td><?php echo $row['date_reg']; ?></td>
            </tr>
          </table>
           </div>
           </div>
           </div>
          


    </div>
  </div>
</div>
  </section>

<?php include("include/footer.php"); ?>
