<?php

include("include/header.php");


include("include/navbar.php");


?>




  <section>
  <div class="display-4 my-2"><a href="index.php">DASHBOARD</a></div>
        <div class="container">
          <div class="row d-flex justify-content-center">
          <div class="col-md-12">
            <h5 class="text-center text-success"><strong>ALL PATIENTS</strong></h5>
            <div class="card shadow min-vh-50">
              <div class="card-body">
                <div class="result"></div>
           </div>
          </div>
          </div>
        </div>
       </div>
      </div>
  </section>



 <script type="text/javascript">
   
 $(document).ready(function(){
   
   show();
   function show(){

     $.ajax({
      url:"ajax/patients.php",
      method:"POST",
      success:function(data){
        $(".result").html(data);
      }

     });

}

});



 </script>




<?php include("include/footer.php");   ?>