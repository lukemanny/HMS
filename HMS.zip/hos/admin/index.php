<?php

include("include/header.php");
include("include/navbar.php");


?>


  <section>
  <h6 class="pt-3">WELCOME <?php echo $_SESSION['admin']; ?></h6>
  <div class="display-4 my-2"><a href="index.php">DASHBOARD</a></div>
  <div class="container">
   <div class="row gy-4 d-flex justify-content-center my-4">
     <div class="col-md-4">
      <div class="card shadow min-vh-50 bg-white">
        <div class="card-body text-center">
          <h3 class='total_admin'>value</h3>
          <h3>Total Admin</h3>
          <div class="card-footer"><a href="add_admin.php">More Info</a></div>
        </div>  
      </div>
     </div>

  <div class="col-md-4">
      <div class="card shadow min-vh-50">
        <div class="card-body text-center">
          <h3 class='total_doctors'>value</h3>
          <h3>Total Doctors</h3>
          <div class="card-footer"><a href="doctor.php">More Info</a></div>
        </div>  
      </div>
     </div>

       <div class="col-md-4">
      <div class="card shadow min-vh-50">
        <div class="card-body text-center">
          <h3 class='total_patients'>value</h3>
          <h3>Total Patients</h3>
          <div class="card-footer"><a href="appointment.php">More Info</a></div>
        </div>  
      </div>
     </div>
  </div>



   <div class="row gy-4 d-flex justify-content-center my-4">

     <div class="col-md-4">
      <div class="card shadow min-vh-50 bg-white">
        <div class="card-body text-center">
          <h3 class='total_report'>value</h3>
          <h3>Total Report</h3>
          <div class="card-footer"><a href="report.php">More Info</a></div>
        </div>  
      </div>
     </div>

  <div class="col-md-4">
      <div class="card shadow min-vh-50">
        <div class="card-body text-center">
          <h3 class='total_job_request'>value</h3>
          <h3>Total Job Request</h3>
          <div class="card-footer"><a href="job_request.php">More Info</a></div>
        </div>  
      </div>
     </div>

       <div class="col-md-4">
      <div class="card shadow min-vh-50">
        <div class="card-body text-center">
          <?php
                  
                  include("../include/db.php");
                         
                 $all_income = mysqli_query($connect,"SELECT SUM(amount_paid) as profit FROM income ");
                 $row = mysqli_fetch_array($all_income);
                 $total_income = $row['profit'];
              
                  ?>
                  <h3>#<?php echo number_format(($total_income),2) ;?></h3>

          <h3>Total Income</h3>
          <div class="card-footer"><a href="income.php">More Info</a></div>
        </div>  
      </div>
     </div>
   </div>
  </div>
</section>




<script type="text/javascript">
  
 $(document).ready(function(){

   $.ajax({
    url:"ajax/index.php",
    method:"POST",
    dataType:"JSON",
    success:function(data){
      $(".total_admin").text(data.total_admin);
      $(".total_doctors").text(data.total_doctors);
      $(".total_patients").text(data.total_patients);
      $(".total_report").text(data.total_report);
      $(".total_job_request").text(data.total_job_request);
      $(".total_income").text(data.total_income);




    }


   });


 });



</script>



<?php include("include/footer.php"); ?>
