<?php


error_reporting(0);

include("../include/db.php");

session_start();

$query = "SELECT * FROM doctor WHERE status='Approved' ";
$res = mysqli_query($connect,$query);

$output ="";

        $output ="
          <table class='table table-bordered table-striped table-responsive'>
          <tr class='bg-secondary text-center'>
          <td>ID</td>
          <td>FIRSTNAME</td>
          <td>SURNANE</td>
          <td>USERNAME</td>
          <td>EMAIL</td>
          <td>GENDER</td>
          <td>STATE</td>
          <td>PHONE</td>
          <td>SALARY</td>
          <td>DATE APPLIED</td>
          <td>ACTION</td>
          </tr>
        ";
  
  if(mysqli_num_rows($res) < 1){
  	$output .="
          <tr>
          <td colspan='11' class='text-center'>NO APPROVED DOCTOR YET</td>
          </tr>
  	";

  }


while($row = mysqli_fetch_array($res)){
     $output .="
     <tr>
      <td>".$row['id']."</td>
      <td>".$row['firstname']."</td>
      <td>".$row['surname']."</td>
      <td>".$row['username']."</td>
      <td>".$row['email']."</td>
      <td>".$row['gender']."</td>
      <td>".$row['state']."</td>
      <td>".$row['phone']."</td>
       <td>#".number_format($row['salary'],2)."</td>
       <td>".$row['data_reg']."</td>
        <td>
        <div class='col'>
        <a href='view_doctors.php?id=".$row['id']."'><button class='btn btn-info col-12'>EDIT</button> </a>

        </div>
        </td>


     ";

}

$output .="
       </tr>
       </table>
";




echo $output;





?>