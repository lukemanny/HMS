<?php

session_start();

include("../include/db.php");

$username = $_POST['username'];
$password = $_POST['password'];
$cpass = $_POST['cpass'];

$error = array();


$new_hash = password_hash($password, PASSWORD_DEFAULT);

if(empty($username)){
	$error['e'] = "Enter Username";
}else if(empty($password)){
	$error['e'] = "Enter Password";
}else if(empty($cpass)){
	$error['e'] = "Enter Confirm Password";
}else if(!password_verify($cpass,$new_hash)){
	$error['e'] = "Confirm Password do not match";
}


$output ="";

if (isset($error['e'])) {
	$output .="<h5 class='text-center alert alert-danger'>".$error['e']."</h5>";
}else{

}


if(count($error) < 1){
    $q = "INSERT INTO admin(username,password) VALUES('$username','$new_hash')";
    $r = mysqli_query($connect,$q);
    if($r){
    	$output .="<h5 class='text-center alert alert-success'>You have successfully added a new admin</h5>";
    }else{
    	$output .="<h5 class='text-center alert alert-danger'>error occured.</h5>";
    }

}






echo $output;






?>