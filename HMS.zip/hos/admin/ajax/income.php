<?php

error_reporting(0);

session_start();

include("../include/db.php");



 $query = "SELECT * FROM income";
 $res = mysqli_query($connect,$query);

 $output ="";

 $output .= "
        <table class='table table-bordered table-striped table-responsive'>
        <tr class='text-center bg-secondary'>
        <td>ID</td>
        <td>DOCTORS</td>
        <td>PATIENTS</td>
        <td>DATE DISCHARGED</td>
        <td>AMOUNT PAID</td>
        <td>DESCRIPTION</td>
        </tr>

 ";


if(mysqli_num_rows($res) < 1){
	$output .="
	<tr>
     <td colspan='6' class='text-center'>NO PATIENT DISCHARGED YET</td>
	</tr>";
}

 while($row = mysqli_fetch_array($res)){
   $output .="
        <tr>
        <td>".$row['id']."</td>
        <td>".$row['doctor']."</td>
        <td>".$row['patient']."</td>
        <td>".$row['date_discharged']."</td>
        <td>#".number_format($row['amount_paid'],2)."</td>
        <td>".$row['description']."</td>

   ";
}


$output .="
    </tr>
    </table>

";



echo $output;




?>