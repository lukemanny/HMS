<?php


include("../include/db.php");

session_start();


$all_admin = mysqli_query($connect,"SELECT * FROM admin");
$total_admin = mysqli_num_rows($all_admin);


$all_doctors = mysqli_query($connect,"SELECT * FROM doctor where status='Approved' ");
$total_doctors = mysqli_num_rows($all_doctors);

$all_patients = mysqli_query($connect,"SELECT * FROM patient");
$total_patients = mysqli_num_rows($all_patients);


$all_report = mysqli_query($connect,"SELECT * FROM report");
$total_report = mysqli_num_rows($all_report);

$all_job_request = mysqli_query($connect,"SELECT * FROM doctor WHERE status='pending' ");
$total_job_request = mysqli_num_rows($all_job_request);



$data = array(
  "total_admin" => $total_admin,
   "total_doctors" => $total_doctors,
   "total_patients" => $total_patients,
   "total_report" => $total_report,
   "total_job_request" => $total_job_request
  

);



echo json_encode($data);









?>