<?php


include("../include/db.php");

if(isset($_POST['action'])){
  if($_POST['action'] == 'remove'){

    $id = $_POST['id'];

    $query = "DELETE FROM admin WHERE id='$id' ";
    $res = mysqli_query($connect,$query);

    if($res){

    }

  }


}




?>