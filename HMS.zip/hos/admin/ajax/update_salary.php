<?php

session_start();

include("../include/db.php");

$id = $_GET['id'];
$salary = $_POST["salary"];

$error = array();

if(empty($salary)){
	$error['e'] = "Enter salary";
}



$output ="";

if(count($error) < 1){
  
   $query = "UPDATE admin SET salary='$salary' WHERE id='$id' ";
   $res = mysqli_query($connect,$query);
   if ($res) {
   	$output  .="<h5 class='text-center alert alert-success'>Salary Updated Successful</h5>" ;
   }else{
   	$output  .="<h5 class='text-center alert alert-danger'>oops! failed to update</h5>" ;
   }


}

if(isset($error['e'])){
	$output  .="<h5 class='text-center alert alert-danger'>Enter Salary</h5>" ;

}else{

}

echo $output;

?>