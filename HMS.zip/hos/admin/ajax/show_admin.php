<?php


session_start();

include("../include/db.php");

$username = $_SESSION['admin'];

$query = "SELECT * FROM admin WHERE username!='$username' ";
$res = mysqli_query($connect,$query);

$output ="";

   $output .="
         <table class='table table-bordered table-striped'>
          <tr>
           <td>ID</td>
           <td>Username</td>
           <td>ACTION</td>
          </tr>
   ";

    if(mysqli_num_rows($res) < 1){
    	$output .="
    	 <tr>
    	 <td colspan='2' class='text-center'>NO NEW ADMIN ADDED!</td>
         </tr>
    	";
    }

 while($row = mysqli_fetch_array($res)){
 	$output .="
         <tr>
         <td>".$row['id']."</td>
         <td>".$row['username']."</td>
         <td>
         <button class='btn btn-lg btn-danger remove' id='".$row['id']."'>DELETE</button>
         </td>
         

 	";
 }
 
 $output .="
      </tr>
      </table>

 ";


echo $output;

?>