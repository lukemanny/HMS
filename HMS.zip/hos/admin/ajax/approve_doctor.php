<?php


include("../include/db.php");

if(isset($_POST['action'])){
  if($_POST['action'] == 'approve'){

    $id = $_POST['id'];

    $query = "UPDATE doctor SET status='Approved' WHERE id='$id' ";
    $res = mysqli_query($connect,$query);

    if($res){

    }

  }


}




?>