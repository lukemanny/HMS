<?php


session_start();

include("../include/db.php");



 $query = "SELECT * FROM patient";
 $res = mysqli_query($connect,$query);

 $output ="";

 $output .= "
        <table class='table table-bordered table-striped table-responsive'>
        <tr>
        <td>ID</td>
        <td>FIRSTNAME</td>
        <td>SURNANE</td>
        <td>USERNAME</td>
        <td>EMAIL</td>
        <td>PHONE</td>
        <td>GENDER</td>
        <td>STATE</td>
        <td>DATE REGISTRED</td>
        <td>ACTION</td>
        </tr>

 ";


if(mysqli_num_rows($res) < 1){
	$output .="
	<tr>
     <td colspan='10' class='text-center'>NO PATIENTS YET</td>
	</tr>";
}

 while($row = mysqli_fetch_array($res)){
   $output .="
        <tr>
        <td>".$row['id']."</td>
        <td>".$row['firstname']."</td>
        <td>".$row['surname']."</td>
        <td>".$row['username']."</td>
        <td>".$row['email']."</td>
        <td>".$row['phone']."</td>
        <td>".$row['gender']."</td>
        <td>".$row['state']."</td>
        <td>".$row['date_reg']."</td>
        <td>
         <div class='col'>
           <a href='view_patients.php?id=".$row['id']."'><button class='btn btn-info col-12'>VIEW</button> </a>
         </div>
        </td>

   ";
}


$output .="
    </tr>
    </table>

";



echo $output;




?>