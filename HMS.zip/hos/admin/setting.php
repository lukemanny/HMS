<?php

include("include/header.php");

include("include/navbar.php");


?>

  <section>
  <div class="display-4 my-2"><a href="index.php">DASHBOARD</a></div>

             <div class="container">
             <div class="row d-flex justify-content-center">
             <div class="col-md-6">
              <div class="card shadow min-vh-50">
              <div class="card-body">
                <h3 class="text-center my-3 text-success">CHANGE PASSWORD</h3>
                <div class="result"></div>
                <form method="POST" id="change_pass">
                <label class="pt-2">Old Password</label>
                <input type="password" name="oldp" id="oldp" class="form-control" placeholder="Enter Old Password">
                <label class="pt-3">New Password</label>
                <input type="password" name="password" id="password" class="form-control" placeholder="Enter Password">
                <label class="pt-3">Confirm Password</label>
                <input type="password" name="cpass" id="cpass" class="form-control" placeholder="Enter Confirm Password">
                <input type="submit" name="change" id="change" value="Add New Admin" class="form-control btn btn-success my-3">
              </form>
              </div>
             </div>
           </div>
         </div>
       </div>


      </div>
  </section>


<script type="text/javascript">
  
 $(document).ready(function(){
  
  $("#change").click(function(e){
    e.preventDefault();

    $.ajax({
     url:"ajax/setting.php",
     method:"POST",
     data:$("#change_pass").serialize(),
     success:function(data){
      $(".result").html(data);
     }




    });  


});

 });







</script>




<?php include("include/footer.php");   ?>