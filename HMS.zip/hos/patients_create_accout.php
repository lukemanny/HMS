<?php

include("include/header.php");

include("include/navbar.php");

?>



<section>
 <div class="container">
 <form method="POST" enctype="multipart/form-data" id="reg_form">
 <div class="card shadow min-vh-50">
 <div class="card-body">
 <h5 class="text-center bg-gray">CREATE ACCOUNT!</h5>

<div class="result"></div>
 <div class="row d-flex justify-content-center">
 <div class="col-6">
  <h6>Firstname</h6>
  <input type="text" name="firstname" id="firstname" placeholder="Enter Firstname" class="form-control my-2">
  <h6>Username</h6>
  <input type="text" name="username" id="username" placeholder="Enter username" class="form-control my-2">
  <h6>Phone Number</h6>
  <input type="text" name="phone" placeholder="Enter Phone Number" id="phone" class="form-control my-2">
 <h6>State</h6>
  <select name="state" class="form-select my-2">
  	<option value="">Select State</option>
    <option value="Abia">Abia</option>
    <option value="Adamawa">Adamawa</option>
    <option value="Akwa-Ibom">Akwa-Ibom</option>
    <option value="Anambra">Anambra</option>
    <option value="Bauchi">Bauchi</option>
    <option value="Benue">Benue</option>
    <option value="Borno">Borno</option>
    <option value="Crossriver">Crossriver</option>
    <option value="Delta">Delta</option>
    <option value="Edo">Edo</option>
    <option value="Bayelsa">Bayelsa</option>
    <option value="Ebonyi">Ebonyi</option>
    <option value="Enugu">Enugu</option>
    <option value="Imo">Imo</option>
    <option value="Jigawa">Jigawa</option>
    <option value="Kaduna">Kaduna</option>
    <option value="Katsina">Katsina</option>
    <option value="Kano">Kano</option>
    <option value="Kebi">Kebi</option>
    <option value="Kogi">Kogi</option>
    <option value="Kwara">Kwara</option>
    <option value="Lagos">Lagos</option>
    <option value="Ekiti">Ekiti</option>
    <option value="Gobe">Gobe</option>
    <option value="Niger">Niger</option>
    <option value="Ogun">Ogun</option>
    <option value="Ondo">Ondo</option>
    <option value="Osun">Osun</option>
    <option value="Oyo">Oyo</option>
    <option value="Plateua">Plateau</option>
    <option value="Rivers">Rivers</option>
    <option value="Sokoto">Sokoto</option>
    <option value="Taraba">Taraba</option>
    <option value="Yobe">Yobe</option>
    <option value="Nassarawa">Nassarawa</option>
    <option value="Zamfara">Zamfara</option>
  </select>
 
 <h6>Confirm Password</h6>
  <input type="password" name="cpass" placeholder="Enter Confirm Password" id="cpass" class="form-control my-2">
</div>
 <div class="col-6">
  <h6>Surname</h6>
  <input type="text" name="surname" placeholder="Enter Surname" id="surname" class="form-control my-2">
   <h6>Email</h6>
  <input type="email" name="email" placeholder="Enter Email Address" id="email" class="form-control my-2">
  <h6>Gender</h6>
  <select name="gender" class="form-select my-2">
  	<option value="">Select Gender</option>
    <option value="male">MALE</option>
    <option value="female">FEMALE</option>
  </select>
 <h6>Password</h6>
  <input type="password" name="password" placeholder="Enter Password" id="password" class="form-control my-2">
  <h6>Picture</h6>
  <input type="file" name="profile" placeholder="Enter Profile" id="profile" class="form-control my-2">
 </div>
 <div class="row d-flex justify-content-center">
 <div class="col-md-6">
 <input type="submit" name="register" id="register" class="btn btn-success btn-lg my-2 col-sm-12" value="Create Now">
</div>
</div>
  <p class="text-center">Already have an Account? <a href="patients_login.php">click here.</a></p>
</div>
</div>
</div>
</form>
</div>
</section>









<script type="text/javascript">
  
  $(document).ready(function(){
      
      $("#reg_form").on("submit",function(e){
        e.preventDefault();
        
       $.ajax({
        url:"ajax/patients_create_accout.php",
        method:"POST",
        data: new FormData(this),
        contentType:false,
        cache:false,
        processData:false,
        success:function(data){
         $(".result").html(data);
        }


       });

      });
  });












</script>




<?php

include("include/footer.php");


?>