<?php

session_start();

include("../include/db.php");


$username = $_POST['username'];
$password = $_POST['password'];

$error = array();


$query = mysqli_query($connect,"SELECT * FROM doctor where username='$username' ");
$row = mysqli_fetch_array($query);
$new_hash = $row['password'];

$output ="";

if(empty($username)){
	$error['e'] = "Enter Username";
}else if(empty($password)){
	$error['e']= "Enter Password";
}else if(!password_verify($password, $new_hash)){
	$error['e'] = "Incorrect Password";
}else if($row['status'] == "pending"){
	$error['e'] = "Your request is under review";
}else if($row['status'] == "rejected"){
	$error['e'] = "Your request failed.";
}

if(isset($error['e'])){
  $output .="<h5 class='alert alert-danger text-center'>".$error['e']."</h5>";
}else{

}

if(count($error) < 1){
	$_SESSION['doctor'] = $username;
	echo "<script> window.location.href='doctor/index.php'</script>";
	 $output .="<h5 class='alert alert-success text-center'>You have successfully logged In</h5>";

	}


echo $output;




?>