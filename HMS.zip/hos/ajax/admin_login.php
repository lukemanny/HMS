<?php


session_start();

include("../include/db.php");


$username = $_POST['username'];
$password = $_POST['password'];

$error = array();

$query = mysqli_query($connect,"SELECT * FROM admin WHERE username='$username' ");
$row = mysqli_fetch_array($query);
$pass_h = $row['password'];


$output ="";

if(empty($username)){
	$error['e'] = "Enter Username";
}else if(empty($password)){
	$error['e'] = "Enter Password";
}else if(password_verify($password,$pass_h)){
     echo "<script> window.location.href='admin/index.php'</script>";
     $_SESSION['admin'] = $username;
     $output ="<h5 class='alert alert-success text-center'>You have successfully logged In<h5/>";

}else{
	$output ="<h5 class='alert alert-danger text-center'> Incorrect credentials<h5/>";

}




if (isset($error['e'])) {
	 $output .="<h5 class='alert alert-danger text-center'>".$error['e']."</h5>";
}else{

}



echo $output;








?>