<?php


include("../include/db.php");


$firstname = $_POST['firstname'];
$surname = $_POST['surname'];
$username = $_POST['username'];
$email = $_POST['email'];
$gender = $_POST['gender'];
$phone = $_POST['phone'];
$state = $_POST['state'];
$password = $_POST['password'];
$cpass = $_POST['cpass'];
$profile = $_FILES['profile']['name'];

$query = mysqli_query($connect,"SELECT * FROM doctor WHERE username='$username' ");

$new_hash = password_hash($password, PASSWORD_DEFAULT);

$error = array();

if(empty($firstname)){
	$error['e'] = "Enter Firstname";
}else if(empty($surname)){
	$error['e'] = "Enter Surname";
}else if(empty($username)){
	$error['e'] = "Enter Username";
}else if(empty($email)){
	$error['e'] = "Enter Email";
}else if($gender == ""){
	$error['e'] = "Select Your Gender";
}else if(empty($phone)){
	$error['e'] = "Enter Phone Number";
}else if($state == ""){
	$error['e'] = "Select Your State";
}else if(empty($password)){
	$error['e'] = "Enter Your Password";
}else if($password != $cpass){
	$error['e'] = "Confirm Password do not match";
}else if(empty($profile)){
	$error['e'] = "please upload your photo";
}else if(mysqli_num_rows($query) > 0){
	$error['e'] = "Username name already exist";
}


$output ="";

if(isset($error['e'])){
	$output .="
      <h5 class='alert text-center alert-danger'>".$error['e']."</h5>
	";
}else{

}


if(count($error) < 1){
   
   $q = "INSERT INTO doctor(firstname,surname,username,email,gender,phone,state,password,salary,data_reg,status,profile) VALUES('$firstname','$surname','$username','$email','$gender','$phone','$state','$new_hash','0',NOW(),'pending','$profile') ";

   $qr = mysqli_query($connect,$q);

   if($qr){
   	$output .="<h5 class='text-center alert alert-success'>You have successfully created an Account.</h5>";
   	move_uploaded_file($_FILES['profile']['tmp_name'], "../doctor/img/$profile");
   }else{
   	   	$output .="<h5 class='alert alert-danger text-center'>Error occured.</h5>";
   }
  

}







echo $output;



?>