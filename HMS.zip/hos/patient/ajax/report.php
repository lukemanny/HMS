<?php

session_start();

include("../include/db.php");



$title = $_POST["title"];
$message = $_POST["message"];



$username = $_SESSION['patient'];


if(empty($title)){
	echo "<p class='alert alert-danger text-center'>Please enter title of your message</p>";
}else if(empty($message)){
	echo "<p class='alert alert-danger text-center'>Enter your message</p>";
}else{
	$query = "INSERT INTO report(title,message,username,report_date) VALUES('$title','$message','$username',NOW() )";

	$res = mysqli_query($connect,$query);

	if($res){
		echo "<h5 class='alert alert-success text-center'>You Sent A Report</h5>";
	}else{
		echo "<h5 class='alert alert-danger text-center'>Oops error occured</h5>";
	}
}






?>