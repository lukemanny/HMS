<?php


session_start();

include("../include/db.php");

$username = $_SESSION['patient'];

$query = "SELECT * FROM appointment WHERE status='discharged' AND firstname='$username' ";
$res = mysqli_query($connect,$query);

$output ="";

$output .="
       <div class='card shadow min-vh-50'>
       <div class='card-body'>
       <table class='table table-striped table-responsive table-bordered'>
       <tr>
       <td>ID</td>
       <td>FIRSTNAME</td>
       <td>SURNANE</td>
       <td>PHONE NUMBER</td>
       <td>GENDER</td>
       <td>APPOINTMENT_DATE</td>
       <td>SYMPTOMS</td>
       <td>DATE_BOOKED</td>
       <td>DOCTOR</td>
       <td>ACTION</td>
       </tr>
   
";

  if(mysqli_num_rows($res) < 1){
  	$output .="
           <tr>
           <td colspan='9' class='text-center'>NO INVOICE YET!</td>
           </td>
  	";
  }


      while($row = mysqli_fetch_array($res)){
      	$output .="
              <tr>
              <td>".$row['id']."</td>
              <td>".$row['firstname']."</td>
              <td>".$row['surname']."</td>
              <td>".$row['phone']."</td>
              <td>".$row['gender']."</td>
              <td>".$row['appointment_date']."</td>
              <td>".$row['symptoms']."</td>
              <td>".$row['date_booked']."</td>
              <td>".$row['doctor']."</td>
              <td>
              <button type='button' class='btn btn-primary col-12' data-toggle='modal' data-target='#ee'>VIEW</button>
              </td>

      	";
      }

       $output .="
           </tr>
           </table>
           </div>
           </div>

       ";


echo $output;




?>