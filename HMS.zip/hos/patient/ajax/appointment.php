<?php


session_start();

include("../include/db.php");


$date = $_POST['date'];
$doctor = $_POST['doctor'];
$symptoms = $_POST['symptoms'];

$username = $_SESSION['patient'];


$error = array();

$query = "SELECT * FROM patient WHERE username='$username' ";
$res = mysqli_query($connect,$query);
$row= mysqli_fetch_array($res);
$firstname = $row['firstname'];
$surname = $row['surname'];
$gender = $row['gender'];
$phone = $row['phone'];



if(empty($date)){
	$error['e'] = "Enter Appointment Date";
}else if($doctor == ""){
	$error['e'] = "Please Select Doctor";
}else if(empty($symptoms)){
	$error['e'] = "Enter symptoms";
}

$output ="";


if(count($error) < 1){
	$query = "INSERT INTO appointment(firstname,surname,gender,phone,appointment_date,symptoms,status,date_booked,doctor) VALUES('$firstname','$surname','$gender','$phone','$date','$symptoms','pending',NOW(),'$doctor')";
	$qr = mysqli_query($connect,$query);

if($qr){
	$output .="<p class='alert alert-success text-center'>You have successfully Booked an Appointment.</p>";
}else{
  $output .="<p class='alert alert-danger text-center'>Oops failed to Book an Appointment</p>";	
}

}


if(isset($error['e'])){
 $output .="<p class='text-center alert alert-danger'>".$error['e']."</p>";
}else{

}


echo $output;




?>