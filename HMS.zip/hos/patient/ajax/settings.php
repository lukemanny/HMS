<?php

session_start();

include("../include/db.php");




$oldp = $_POST['oldp'];
$password = $_POST['password'];
$cpass = $_POST['cpass'];


$error = array();

$username = $_SESSION['patient'];

$query = mysqli_query($connect,"SELECT password FROM patient WHERE username='$username' ");
$row = mysqli_fetch_array($query);
$old_pass = $row['password'];
$new_hash = password_hash($password, PASSWORD_DEFAULT);


if(empty($oldp)){
	$error['e'] = "Enter Old password";
}else if(empty($password)){
    $error['e'] = "Enter New Password";
}else if(empty($cpass)){
    $error['e'] = "Enter Confirm Password";
}else if(!password_verify($oldp,$old_pass)){
	$error['e'] = "Incorrect Old Password";
}else if(!password_verify($cpass,$new_hash)){
	$error['e'] = "Both New and Confirm Password do not match";
}


$output ="";

if(isset($error['e'])){
   $output .="<h5 class='text-center alert alert-danger'>".$error['e']."</h5>";
}else{

}


if(count($error) < 1){
	$q = "UPDATE patients SET password='$new_hash' WHERE username='$username' ";
	$qr = mysqli_query($connect,$q);
	if($qr){
		$output .="<h5 class='text-center alert alert-success'>Password updated succesfully.</h5>";
	}else{
		$output .="<h5 class='text-center alert alert-danger'>error occured</h5>";
	}
}


echo $output;










?>