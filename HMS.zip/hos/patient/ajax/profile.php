<?php

session_start();

include("../include/db.php");

$username = $_SESSION['patient'];

$query = "SELECT * FROM patient WHERE username='$username'";

$res = mysqli_query($connect,$query);

$row = mysqli_fetch_array($res);

$output ="";

$output .="

     <div class='row d-flex justify-content-center my-1'>

     <div class='col-md-6'> 
      <img src='img/".$row['profile']."' style='width:300px; height:300px; border-radius:50%'>
     <form method='post' class='profile_update' enctype='multipart/form-data' id='profile_update'>



 
      <div class='row d-flex justify-content-center my-1'>
      <div class='col'>
      <input type='file' name='profile' class='form-control' id='profile'> 
      </div>     
       
      <div class='col'>
       <input type='submit' class='btn btn-info' value='update' id='profile'>
      </div>
    
    </div>
     
     </form>
     </div>

    </div>

    
    <table class='table table-striped my-1'>
   <tr>
     <td class='text-center'>Firstname</td>
     <td>".$row['firstname']."</td>
   </tr>
  <tr>
     <td class='text-center'>Surname</td>
     <td>".$row['surname']."</td>
   </tr>
    <tr>
     <td class='text-center'>Username</td>
     <td>".$row['username']."</td>
   </tr>
    <tr>
     <td class='text-center'>Email</td>
     <td>".$row['email']."</td>
   </tr>
    <tr>
     <td class='text-center'>Gender</td>
     <td>".$row['gender']."</td>
   </tr>
    <tr>
     <td class='text-center'>Age</td>
     <td>".$row['state']."</td>
   </tr>
       
   

       </table>

";



echo $output;





?>