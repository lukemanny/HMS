<?php

include("include/header.php");


include("include/navbar.php");


?>



    <section class="content">
      <div class="container-fluid">
             <div class="container">
               <h2 class="my-2"><a href="index.php" class="text-dark">DASHBOARD</a></h2>
                <div class="row d-flex justify-content-center">
                <div class="col-md-8">
                 <div class="card shadow min-vh-50 my-4">
                  <h3 class="bg-info text-center p-3">BOOK APPOINTMENT</h3>
                  <div class="card-body">
                    <form method="POST" id="appoint_form">
                    <div class="result"></div>
                      <label class="pt-2">Appointment Date</label>
                      <input type="date" name="date" id="name" placeholder="choose date" class="form-control">
                      <label class="pt-2">Choose Doctor</label>
                      <select name="doctor" class="form-control">
                        <option value="">choose Doctor</option>
                        <?php

                        session_start();

                        include("../include/db.php");

                        $query = "SELECT * FROM doctor WHERE status='Approved' ";
                        $res = mysqli_query($connect,$query);


                        while($row = mysqli_fetch_array($res)){
                            
                         echo "<option value='".$row['firstname']."'>".$row['firstname']."</option>";

                          
                        }
                         
                         
                        ?>
                      </select>
                      <label class="pt-2">Symptoms</label>
                      <textarea name="symptoms" class="form-control"></textarea>
                      <input type="submit" name="appoint" id="appoint" class="btn btn-success btn-lg my-3 col-12" value="Book">
                    </form>
                    </div>
                 </div>
               </div>
              </div>
            </div>
            </div>
      </div>
  </section>





<script type="text/javascript">
  
$(document).ready(function(){
  
  $("#appoint").click(function(e){
   e.preventDefault();
    
    $.ajax({
     url:"ajax/appointment.php",
     method:"POST",
     data:$("#appoint_form").serialize(),
     success:function(data){
      $(".result").html(data);
     }
  

    });

  });



});







</script>






<?php  include("include/footer.php")  ?>