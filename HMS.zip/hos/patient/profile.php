<?php

include("include/header.php");


include("include/navbar.php");


?>



    <section class="content">
          <div class="container">
           <h2 class="my-2"><a href="index.php" class="text-dark">DASHBOARD</a></h2>
            <div class="container">
             <h5 class="text-center">MY PROFILE</h5>
              <div class="card shadow min-vh-50">
               <div class="card-body">
                <div class="result"></div>
               </div>
              </div>
            </div>
          </div>
  </section>





<script type="text/javascript">
  
 $(document).ready(function(){

    show();
    function show(){

     $.ajax({
     url:"ajax/profile.php",
     method:"POST",
     success:function(data){
      $(".result").html(data);
     }
   
   });

    }

    $(document).ready(function(){

    $(document).on("submit", "#profile_update", function(e){
      e.preventDefault();

      $.ajax({
        url:"ajax/change_profile.php",
        method:"POST",
        data: new FormData(this),
        contentType:false,
        cache:false,
        processData:false,
        success:function(data){
          show();
        }



      });


    });



    });


 });











</script>






<?php include("include/footer.php"); ?>