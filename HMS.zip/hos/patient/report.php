<?php

include("include/header.php");


include("include/navbar.php");


?>



    <section class="content">
      <div class="container-fluid">
             <div class="container">
               <h2 class="my-2"><a href="index.php" class="text-dark">DASHBOARD</a></h2>
             <div class="container">
              <div class="row d-flex justify-content-center">
                <div class="col-md-6">
                  <h3 class="text-center">SEND A REPORT</h3>
                  <form method="POST" id="report_form">
                   <div class="card shadow min-vh-50 bg-info">
                    <div class="card-body">
                    <div class="result"></div>
                    
                    <label>Title</label>
                    <input type="text" name="title" id="title" class="form-control my-2" placeholder="Enter Title of your message">
                    <label>Message</label>
                    <textarea name="message" id="message" class="form-control my-2"></textarea>
                    <input type="submit" name="report" id="report" value="SEND" class="form-control btn btn-success my-3">

                  </form>
                </div>
               </div>
                </div>


           </div>
          </div>
      </div>
  </section>





<script type="text/javascript">
  
  $(document).ready(function(){

     $("#report").click(function(e){
      e.preventDefault();
    
      $.ajax({
       url:"ajax/report.php",
       method:"POST",
       data:$("#report_form").serialize(),
       success:function(data){
        $(".result").html(data);
       }

      });

     });


  });
 








</script>






<?php include("include/footer.php") ?>