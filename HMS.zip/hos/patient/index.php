<?php

include("include/header.php");


include("include/navbar.php");


?>




  <section>
  <h6 class="pt-3">WELCOME <?php echo $_SESSION['patient']; ?></h6>
  <div class="display-4 my-2"><a href="doctor/index.php">DASHBOARD</a></div>
  <div class="container">
   <div class="row gy-4 d-flex justify-content-center">

     <div class="col-md-4">
      <div class="card shadow min-vh-50 bg-white">
        <div class="card-body text-center">
          <h2>My</h2>
          <h3>Profile</h3>
          <div class="card-footer"><a href="profile.php">More Info</a></div>
        </div>  
      </div>
     </div>

  <div class="col-md-4">
      <div class="card shadow min-vh-50">
        <div class="card-body text-center">
          <h2>My</h2>
          <h3>Invoice</h3>
          <div class="card-footer"><a href="invoice.php">More Info</a></div>
        </div>  
      </div>
     </div>

       <div class="col-md-4">
      <div class="card shadow min-vh-50">
        <div class="card-body text-center">
          <h2>Book</h2>
          <h3>Appointment</h3>
          <div class="card-footer"><a href="appointment.php">More Info</a></div>
        </div>  
      </div>
     </div>


















   </div>
  </div>
</section>







<?php include("include/footer.php"); ?>
