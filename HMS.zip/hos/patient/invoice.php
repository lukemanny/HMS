<?php

include("include/header.php");


include("include/navbar.php");


?>



    <section class="content">
      <div class="container-fluid">
      <div class="container">
      <h2 class="my-2"><a href="index.php" class="text-dark">DASHBOARD</a></h2>
      <div class="container-fluid">
        <div class="container">
          <div class="row d-flex justify-content-center">
           <div class="col-md-12">
            <h3 class="text-center my-3">MY INVOICE</h3>
           <div class="result"></div>
         </div>
        </div>
      </div>
      </div>
  </section>




  <div class="modal fade" id="ee" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
      <div class="modal-body">
       

          <?php

           include("../include/db.php");

           $username = $_SESSION['patient'];

           
           $query = "SELECT * FROM income WHERE patient='$username' ";
           $res = mysqli_query($connect,$query);
           $row = mysqli_fetch_array($res);

           $output ="";
    
           $output .="
                  <div class='card shadow min-vh-50'>
                  <div class='card-body'>
                  <table class='table'>
                   <tr>
                   <td colspan='2' class='text-center text-info'><strong><h5>INVOICE</h5></strong></td>
                   </tr>
                   <tr>
                   <td>DOCTOR</td>
                   <td class='text-center'>".$row['doctor']."</td>
                   </tr>

                   <tr>
                   <td>PATIENT</td>
                   <td class='text-center'>".$row['patient']."</td>
                   </tr>

                   <tr>
                   <td>DATE DISCHARGED</td>
                   <td class='text-center'>".$row['date_discharged']."</td>
                   </tr>

                   <tr>
                   <td>AMOUNT PAID</td>
                   <td class='text-center'>#".number_format($row['amount_paid'],2)."</td>
                   </tr>

                   <tr>
                   <td>DESCRIPTION</td>
                   <td class='text-center'>".$row['description']."</td>
                   </tr>
                   </table>

           ";

          echo $output;

          ?>


      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>

<?php include("footer.php"); ?>





<script type="text/javascript">
  
   $(document).ready(function(){
     
     $.ajax({
      url:"ajax/invoice.php",
      method:"POST",
      success:function(data){
        $(".result").html(data);
      }


     });


   });








</script>












</body>
</html>