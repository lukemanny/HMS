<?php

include("include/header.php");


include("include/navbar.php");


?>






<section class="login">
	<div class="container my-3">
	 <div class="row d-flex justify-content-center">
	  <div class="col-md-6">
       <div class="card shadow min-vh-50 my-5">
        <h2 class="text-center bg-info text-secondary pt-3 pb-3">DOCTORS LOGIN</h2>
       <form method="POST" id="login_form">
       <div class="result"></div>
        <div class="card-body">
         <h5>Username</h5>
         <input type="text" name="username" id="username" class="form-control my-2" placeholder="Enter username">
         <h5>Password</h5>
         <input type="password" name="password" id="password" class="form-control my-2" placeholder="Enter Password">
         <input type="submit" name="login" id="login" class="btn btn-info text-white btn-lg my-2" value="LOGIN">

        </form>
        </div>
      </div>
   </div>
</div>
</div>
</section>







<script type="text/javascript">
	
$(document).ready(function(){

  $("#login").click(function(e){
  	e.preventDefault();

  	var username = $("#username").val();
  	var password = $("#password").val();

    $.ajax({
      url:"ajax/doctors_login.php",
      method:"POST",
      data:{username:username,password:password},
      success:function(data){
      	$(".result").html(data);
      }




    });

     
 




  });


});





</script>



<?php

include("include/footer.php");



?>
