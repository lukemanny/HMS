<?php

include("include/header.php");

include("include/navbar.php");

?>



<section id="hero">
    <div class="container">
     <div class="row gy-4 d-flex justify-content-center">

        <div class="col-md-4">
          <div class="card shadow min-vh-50">
            <img src="images/info.png" style="height: 250px">
            <div class="card-body">
            <h3 class="pt-2">Click on the button for more information</h3>
            <center><button type="submit" class="btn btn-success btn-lg mb-3" style="margin: auto;">Read More</button></center>
          </div>
         </div>
         </div>


          <div class="col-md-4">
          <div class="card shadow min-vh-50">
            <img src="images/patient.jpg" style="height: 250px;">
            <div class="card-body">
            <h4 class="pt-2">Create Account so that we can take care of You</h4>
            <center><a href="patients_create_accout.php" type="button" class="btn btn-success btn-lg mb-4">Create Account!!!</a></center>
          </div>
         </div>
       </div>


          <div class="col-md-4">
          <div class="card shadow min-vh-50">
            <img src="images/doctor.jpg" style="height: 250px;">
            <div class="card-body">
            <h4 class="pt-2">We are employing for Doctors</h4>
            <center><a href="doctors_apply.php" type="button" class="btn btn-success btn-lg mb-3">Apply Now!!!</a></center>
          </div>
         </div>
        </div>

     </div>
   </div>
</section>



<?php

include("include/footer.php");


?>


</body>
</html>