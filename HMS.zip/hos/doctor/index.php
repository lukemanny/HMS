<?php

include("include/header.php");


include("include/navbar.php");


?>




  <section>
  <h6 class="pt-3">WELCOME <?php echo $_SESSION['doctor']; ?></h6>
  <div class="display-4 my-2"><a href="doctor/index.php">DASHBOARD</a></div>
  <div class="container">
   <div class="row gy-4 d-flex justify-content-center">

     <div class="col-md-4">
      <div class="card shadow min-vh-50 bg-white">
        <div class="card-body text-center">
          <h2>My</h2>
          <h3>Profile</h3>
          <div class="card-footer"><a href="profile.php">More Info</a></div>
        </div>  
      </div>
     </div>

  <div class="col-md-4">
      <div class="card shadow min-vh-50">
        <div class="card-body text-center">
          <h2 class="total_patients">Value</h2>
          <h3>Total Patient</h3>
          <div class="card-footer"><a href="patients.php">More Info</a></div>
        </div>  
      </div>
     </div>

       <div class="col-md-4">
      <div class="card shadow min-vh-50">
        <div class="card-body text-center">
          <h2 class="total_appointment">Value</h2>
          <h3>Appointment</h3>
          <div class="card-footer"><a href="appointment.php">More Info</a></div>
        </div>  
      </div>
     </div>


















   </div>
  </div>
</section>




<script type="text/javascript">
  $(document).ready(function(){
   
   $.ajax({
    url:"ajax/index.php",
    method:"POST",
    dataType:"JSON",
    success:function(data){
     $(".total_patients").text(data.total_patients);
     $(".total_appointment").text(data.total_appointment);
    }



   });



  });






</script>


<?php include("include/footer.php"); ?>
