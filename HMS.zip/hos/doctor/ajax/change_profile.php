<?php

session_start();

include("../include/db.php");

$username = $_SESSION['doctor'];

 $profile = $_FILES['profile']['name'];

     $query = "UPDATE doctor SET profile='$profile' WHERE username='$username'";
     $res = mysqli_query($connect,$query);

     if($res){
        move_uploaded_file($_FILES['profile']['tmp_name'], "../img/$profile");
     }
     


?>