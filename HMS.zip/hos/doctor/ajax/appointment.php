<?php


session_start();

include("../include/db.php");

$username = $_SESSION['doctor'];

$q = mysqli_query($connect,"SELECT * FROM doctor WHERE username='$username' ");

$rows = mysqli_fetch_array($q);
$firstname = $rows['firstname'];



$query = "SELECT * FROM appointment WHERE doctor='$firstname' AND status='pending' ";

$res = mysqli_query($connect,$query);

$output = "";

$output .="
         <div class='col-md-12'>
          <div class='card shadow min-vh-50'>
           <div class='card-body'>
           <table class='table table-striped table-responsive'>
           <tr>
           <th>ID</th>
           <th>FIRSTNAME</th>
           <th>SURNAME</th>
           <th>GENDER</th>
           <th>PHONE</th>
           <th>APPOINTMENT_DATE</th>
           <th>SYMPTOMS</th>
           <th>DATE_BOOKED</th>
           <th>ACTION</th>
           </tr>


";

      if(mysqli_num_rows($res) < 1){
      	$output .="
          <tr>
          <td colspan='9' class='text-center'>NO APPOINTMENT YET!</td>
          </tr>
      	";
      }


  while($row = mysqli_fetch_array($res)){
      $output .="
            <tr>
            <td>".$row['id']."</td>
            <td>".$row['firstname']."</td>
            <td>".$row['surname']."</td>
            <td>".$row['gender']."</td>
            <td>".$row['phone']."</td>
            <td>".$row['appointment_date']."</td>
            <td>".$row['symptoms']."</td>
            <td>".$row['date_booked']."</td>
            <td>
             <a href='discharge.php?id=".$row['id']."' class='btn btn-info btn-lg'>CHECK</a>

            </td>

      ";

  }

  $output .="
     </tr>
     </table>
     </div>
     </div>
     </div>



  ";


echo $output;








?>