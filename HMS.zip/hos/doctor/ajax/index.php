<?php



include("../include/db.php");

session_start();

$all_patients = mysqli_query($connect,"SELECT * FROM patient");
$total_patients = mysqli_num_rows($all_patients);

$username = $_SESSION['doctor'];

$q = mysqli_query($connect,"SELECT * FROM doctor WHERE username='$username' ");

$rows = mysqli_fetch_array($q);
$firstname = $rows['firstname'];



$query = "SELECT * FROM appointment WHERE doctor='$firstname' AND status='pending' ";

$res = mysqli_query($connect,$query);

$total_appointment = mysqli_num_rows($res);

$data = array(
   
   "total_patients" => $total_patients,
   "total_appointment" => $total_appointment

);

echo json_encode($data);












?>