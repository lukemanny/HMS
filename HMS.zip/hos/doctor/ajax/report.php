<?php



include("../include/db.php");

 $query = "SELECT * FROM report";

 $res = mysqli_query($connect,$query);

 $output ="";

 $output .="
      <div class='card shadow min-vh-50'>
      <div class='card-body'>
      <table class='table table-striped'>
      <tr class='bg-secondary'>
      <td>ID</td>
      <td>TITLE</td>
      <td>MESSAGE</td>
      <td>USERNAME</td>
      <td>REPORT DATE</td>
      </tr>

 ";


   if(mysqli_num_rows($res) < 1){
      $output .="
         <tr>
         <td colspan='5' class='text-center'>NO REPORT YET!</td>
         </tr>

      ";

   }


   while($row = mysqli_fetch_array($res)){
       $output .="
           <tr>
           <td>".$row['id']."</td>
           <td>".$row['title']."</td>
           <td>".$row['message']."</td>
           <td>".$row['username']."</td>
           <td>".$row['report_date']."</td>


       ";
   }

$output .="
        </tr>
        </table>
        </div>
        </div>

";

echo $output;







?>