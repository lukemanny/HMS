<?php

include("include/header.php");


include("include/navbar.php");


?>


    <section class="content">
      <div class="container-fluid">
        <div class="container">
          <h2 class=""><a href="index.php" class="text-dark">DASHBOARD</a></h2>
          <div class="row d-flex justify-content-center">
         
         <div class="col-md-8">
           <div class="card shadow min-vh-50">
            <div class="card-header text-center bg-success"><strong>DISCHARGE PATIENT</strong></div>
            <div class="card-body">
            <form method="POST" id="discharge_form">
              <div class="result"></div>
       <?php

         if(isset($_POST['discharge'])){

         include('../include/db.php');

         $fee = $_POST['fee'];
         $des = $_POST['des'];

         $error = array();


         $id = $_GET['id'];

       $query = "SELECT * FROM appointment WHERE id='$id' ";
       $res = mysqli_query($connect,$query);
       $row = mysqli_fetch_array($res);
       $firstname = $row['firstname'];

       $doc = $_SESSION['doctor'];

       if(empty($fee)){
        $error['e'] = "Enter Amount";
         }else if(empty($des)){
        $error['e'] = "Enter Description";
         }

       $output = "";


       if(count($error) < 1){
        $query = "INSERT INTO income(doctor,patient,date_discharged,amount_paid,description) VALUES('$doc','$firstname',      NOW(),'$fee','$des')";
       $query_run = mysqli_query($connect,$query);
        if($query_run){
         mysqli_query($connect,"UPDATE appointment SET status='discharged' WHERE id='$id' ") ;
         $output .="<p class='alert alert-success text-center'>Discharged successful.</p>";
         }else{
           $output .="<p class='alert alert-danger text-center'>error occured</p>";
          }
         }


        if (isset($error['e'])) {
          $output .="<p class='alert alert-danger text-center'>".$error['e']."</p>"; 
         }else{

         }

         echo $output;


          }




          ?>
            <label class="my-2">FEE</label>
            <input type="number" name="fee" id="fee" class="form-control" placeholder="Enter Amount">
            <label class="my-2">DESCRIPTION</label>
            <textarea name="des" id='des' class="form-control" placeholder="Enter description for this Patient."></textarea>
            <div>
              <input type="submit" name="discharge" id="discharge" value="DISCHARGE" class="btn btn-success btn-lg my-3">
            </div>
           </form>
          </div>
        </div>
      </div>
      </div>

            <div class="row d-flex justify-content-center my-4">
            <div class="col-md-8">
              <?php
         

           include("../include/db.php");

           $id = $_GET['id'];


           $query = "SELECT * FROM appointment WHERE id='$id' ";
           $res = mysqli_query($connect,$query);

           $row = mysqli_fetch_array($res);


          ?>
         <h3 class="text-center text-success"><strong><?php echo $row['firstname'] ." ". $row['surname']."'s Details ";  ?></strong></h3>
         <div class="card shadow min-vh-50">
         <div class="card-body">
           <table class="table table-striped table-bordered">
            <tr>
            <td class="text-center">PHONE NUMBER<td><?php echo $row['phone']; ?></td>
            </tr>
            <tr>
            <td class="text-center">GENDER</td><td><?php echo $row['gender']; ?></td>
            </tr>
            <tr>
            <td class="text-center">SYMPTOMS</td><td><?php echo $row['symptoms']; ?></td>
            </tr>
            <td class="text-center">APPOINTMENT DATE</td><td><?php echo $row['appointment_date']; ?></td>
            </tr>
             <tr>
            <td class="text-center">DATE BOOKED</td><td><?php echo $row['date_booked']; ?></td>
            </tr>
          </table>
           </div>
           </div>
           </div>
          


    </div>
  </div>
</div>
  </section>

<?php include("include/footer.php"); ?>
