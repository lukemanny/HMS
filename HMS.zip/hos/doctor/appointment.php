<?php

include("include/header.php");


include("include/navbar.php");


?>


    <section class="content">
      <div class="container-fluid my-5">
        <h2 class=""><a href="index.php" class="text-dark">DASHBOARD</a></h2>
             <div class="container my-3">
               <h3 class="text-center">Appointment List</h3>
                <div class="row d-flex justify-content-center">
                  <div class="result">


                  </div>
                </div>
             </div> 
      </div>
  </section>



<script type="text/javascript">
  
 show();
 function show(){

   $.ajax({
     url:"ajax/appointment.php",
     method:"POST",
     success:function(data){
      $(".result").html(data);
     }

   });




 }













</script>



<?php include("include/footer.php"); ?>












</body>
</html>