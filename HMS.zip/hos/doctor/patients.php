<?php

include("include/header.php");


include("include/navbar.php");


?>


    <section class="content my-5">
      <h2 class=""><a href="index.php" class="text-dark">DASHBOARD</a></h2>
      <div class="container-fluid pt-5">
        <h4 class='text-center'>TOTAL PATIENTS</h4>
            <div class="result"></div>
      </div>
  </section>





<script type="text/javascript">
   
 $(document).ready(function(){

    show();
    function show(){

    $.ajax({
     url:"ajax/patients.php",
     method:"POST",
     success:function(data){
      $(".result").html(data);
     }



    });

}
 });






</script>






<?php  include("include/footer.php");   ?>